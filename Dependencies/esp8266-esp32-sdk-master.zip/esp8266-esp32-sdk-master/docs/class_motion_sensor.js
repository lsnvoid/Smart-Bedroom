var class_motion_sensor =
[
    [ "sendMotionEvent", "class_motion_sensor.html#ab28a28a17768a38eea033ba700095672", null ]
];