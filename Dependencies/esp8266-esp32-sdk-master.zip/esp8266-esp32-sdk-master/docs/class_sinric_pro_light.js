var class_sinric_pro_light =
[
    [ "AdjustBrightnessCallback", "class_sinric_pro_light.html#a3ff8d93d9483f41bf8504fd3e9cc8f49", null ],
    [ "BrightnessCallback", "class_sinric_pro_light.html#aff9938ddc803e4339a3db9b31503e12d", null ],
    [ "ColorCallback", "class_sinric_pro_light.html#ad8bcf09f6da3f41fffb001868cd3f84e", null ],
    [ "ColorTemperatureCallback", "class_sinric_pro_light.html#a9828094e72d45dc55a1023fd677f0cc5", null ],
    [ "DecreaseColorTemperatureCallback", "class_sinric_pro_light.html#ae64ac4d2aa913eeb244091c7a13d2ecc", null ],
    [ "IncreaseColorTemperatureCallback", "class_sinric_pro_light.html#aed3d41935f8162074c2a2cc0168164dd", null ],
    [ "PowerStateCallback", "class_sinric_pro_light.html#aad370bc6b280bbdeac98181a31f22df4", null ],
    [ "onAdjustBrightness", "class_sinric_pro_light.html#a0633e5fa2981189f4a093bab00a8c7f1", null ],
    [ "onBrightness", "class_sinric_pro_light.html#abbaab3067b1fcdcc5928451b818a4420", null ],
    [ "onColor", "class_sinric_pro_light.html#a059ff103149869b7c49cdb8911875b7b", null ],
    [ "onColorTemperature", "class_sinric_pro_light.html#a8535c44fd2517ed09ebe6a203cc25b67", null ],
    [ "onDecreaseColorTemperature", "class_sinric_pro_light.html#a7468976e7fffeee14cc869b7236cbb50", null ],
    [ "onIncreaseColorTemperature", "class_sinric_pro_light.html#a7ea9fd9861a5668a41d06267bfbec82a", null ],
    [ "onPowerState", "class_sinric_pro_light.html#a32f3257da431a1035f23a265ff0cc4cf", null ],
    [ "sendBrightnessEvent", "class_sinric_pro_light.html#aa42df8ac91de826653626df67a8500b6", null ],
    [ "sendColorEvent", "class_sinric_pro_light.html#aa3019d161b320267666cdb11d1c3d827", null ],
    [ "sendColorTemperatureEvent", "class_sinric_pro_light.html#a9065e6d08309d313b16adc774cc642ff", null ],
    [ "sendPowerStateEvent", "class_sinric_pro_light.html#a8006e256414deac0f9a4e28774b47773", null ]
];