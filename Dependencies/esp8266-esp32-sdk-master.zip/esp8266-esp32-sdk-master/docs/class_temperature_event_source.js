var class_temperature_event_source =
[
    [ "sendTemperatureEvent", "class_temperature_event_source.html#a9545808dacd9efc40a05f16e09d79b4e", null ]
];