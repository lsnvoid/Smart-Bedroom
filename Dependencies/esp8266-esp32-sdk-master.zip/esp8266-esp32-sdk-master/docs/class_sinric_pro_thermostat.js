var class_sinric_pro_thermostat =
[
    [ "AdjustTargetTemperatureCallback", "class_sinric_pro_thermostat.html#a8d55dffbb520779ef95fc29e49032886", null ],
    [ "PowerStateCallback", "class_sinric_pro_thermostat.html#aad370bc6b280bbdeac98181a31f22df4", null ],
    [ "SetTargetTemperatureCallback", "class_sinric_pro_thermostat.html#a64ecf52eb927d219b3acabf01ad0d31f", null ],
    [ "ThermostatModeCallback", "class_sinric_pro_thermostat.html#a6cb473352a45a2ae76a46a4292c95a8c", null ],
    [ "onAdjustTargetTemperature", "class_sinric_pro_thermostat.html#ac51f6fecfdf4c7bc8e0712e2da47bbf4", null ],
    [ "onPowerState", "class_sinric_pro_thermostat.html#a32f3257da431a1035f23a265ff0cc4cf", null ],
    [ "onTargetTemperature", "class_sinric_pro_thermostat.html#a1c73725f1f3fbb1c5b72208aae5c2bf2", null ],
    [ "onThermostatMode", "class_sinric_pro_thermostat.html#a2ef31536973b20815dd6c80a28e19c9f", null ],
    [ "sendPowerStateEvent", "class_sinric_pro_thermostat.html#a8006e256414deac0f9a4e28774b47773", null ],
    [ "sendTargetTemperatureEvent", "class_sinric_pro_thermostat.html#a07632bca425003b4ad559cb46fabca8c", null ],
    [ "sendTemperatureEvent", "class_sinric_pro_thermostat.html#a9545808dacd9efc40a05f16e09d79b4e", null ],
    [ "sendThermostatModeEvent", "class_sinric_pro_thermostat.html#acd81e847a7f1029163729574c3d3971d", null ]
];