var class_temperature_sensor =
[
    [ "sendTemperatureEvent", "class_temperature_sensor.html#a9545808dacd9efc40a05f16e09d79b4e", null ]
];