var class_sinric_pro_air_quality_sensor =
[
    [ "PowerStateCallback", "class_sinric_pro_air_quality_sensor.html#aad370bc6b280bbdeac98181a31f22df4", null ],
    [ "onPowerState", "class_sinric_pro_air_quality_sensor.html#a32f3257da431a1035f23a265ff0cc4cf", null ],
    [ "sendAirQualityEvent", "class_sinric_pro_air_quality_sensor.html#a3836e4dca79c1563fcdae880bb368323", null ],
    [ "sendPowerStateEvent", "class_sinric_pro_air_quality_sensor.html#a8006e256414deac0f9a4e28774b47773", null ]
];