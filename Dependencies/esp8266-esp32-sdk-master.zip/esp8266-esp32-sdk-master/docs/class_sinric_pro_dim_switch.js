var class_sinric_pro_dim_switch =
[
    [ "AdjustPowerLevelCallback", "class_sinric_pro_dim_switch.html#a3ec3aad26d06f5b943a6906e11afc1f3", null ],
    [ "PowerStateCallback", "class_sinric_pro_dim_switch.html#aad370bc6b280bbdeac98181a31f22df4", null ],
    [ "SetPowerLevelCallback", "class_sinric_pro_dim_switch.html#a5be6c20c0ba9e9b19bd76d42918451b2", null ],
    [ "onAdjustPowerLevel", "class_sinric_pro_dim_switch.html#a13b10bdb1844babe4de320fff9172d96", null ],
    [ "onPowerLevel", "class_sinric_pro_dim_switch.html#a0685d34694badb4442fed6b69b69b366", null ],
    [ "onPowerState", "class_sinric_pro_dim_switch.html#a32f3257da431a1035f23a265ff0cc4cf", null ],
    [ "sendPowerLevelEvent", "class_sinric_pro_dim_switch.html#aaf81884c1f690ff2dd8862e192b8bbfa", null ],
    [ "sendPowerStateEvent", "class_sinric_pro_dim_switch.html#a8006e256414deac0f9a4e28774b47773", null ]
];