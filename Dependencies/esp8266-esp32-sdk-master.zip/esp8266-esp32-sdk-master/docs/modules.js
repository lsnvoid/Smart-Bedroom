var modules =
[
    [ "SinricPro", "group___sinric_pro.html", "group___sinric_pro" ],
    [ "Devices", "group___devices.html", "group___devices" ],
    [ "Capabilities", "group___capabilities.html", "group___capabilities" ]
];