var searchData=
[
  ['handle_42',['handle',['../class_sinric_pro_class.html#a37c2d0658e498b1bf878f8a3d9a7c5b4',1,'SinricProClass']]]
];
