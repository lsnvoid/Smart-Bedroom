var searchData=
[
  ['gettimestamp_291',['getTimestamp',['../class_sinric_pro_class.html#afb2be26eef972203404140612fa31326',1,'SinricProClass']]]
];
