var class_sinric_pro_garage_door =
[
    [ "DoorCallback", "class_sinric_pro_garage_door.html#aaa6633dc67bd8f69e2f14cc0dc0a4466", null ],
    [ "onDoorState", "class_sinric_pro_garage_door.html#a6b536531ab89b39f1a48cb107e22185e", null ],
    [ "sendDoorStateEvent", "class_sinric_pro_garage_door.html#a54e5b81baedd99d5e03383eab7da909e", null ]
];