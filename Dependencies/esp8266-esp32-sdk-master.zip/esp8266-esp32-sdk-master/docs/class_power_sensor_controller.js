var class_power_sensor_controller =
[
    [ "sendPowerSensorEvent", "class_power_sensor_controller.html#a15776ac1a6e2077230d77a69fc670453", null ]
];