var class_sinric_pro_motionsensor =
[
    [ "PowerStateCallback", "class_sinric_pro_motionsensor.html#aad370bc6b280bbdeac98181a31f22df4", null ],
    [ "onPowerState", "class_sinric_pro_motionsensor.html#a32f3257da431a1035f23a265ff0cc4cf", null ],
    [ "sendMotionEvent", "class_sinric_pro_motionsensor.html#ab28a28a17768a38eea033ba700095672", null ],
    [ "sendPowerStateEvent", "class_sinric_pro_motionsensor.html#a8006e256414deac0f9a4e28774b47773", null ]
];