var class_sinric_pro_contactsensor =
[
    [ "PowerStateCallback", "class_sinric_pro_contactsensor.html#aad370bc6b280bbdeac98181a31f22df4", null ],
    [ "onPowerState", "class_sinric_pro_contactsensor.html#a32f3257da431a1035f23a265ff0cc4cf", null ],
    [ "sendContactEvent", "class_sinric_pro_contactsensor.html#a0b4b9006c0be003c615848bcc2b690fd", null ],
    [ "sendPowerStateEvent", "class_sinric_pro_contactsensor.html#a8006e256414deac0f9a4e28774b47773", null ]
];